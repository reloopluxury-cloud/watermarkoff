/// A rectangle the user drew over the watermark, expressed as fractions
/// (0.0-1.0) of the video's width/height rather than raw pixels.
///
/// Storing it as fractions means it doesn't matter what size the preview
/// widget was on screen — we scale it to the real video resolution right
/// before we hand it to FFmpeg.
class MaskRect {
  final double xFraction;
  final double yFraction;
  final double widthFraction;
  final double heightFraction;

  const MaskRect({
    required this.xFraction,
    required this.yFraction,
    required this.widthFraction,
    required this.heightFraction,
  });

  /// Converts this fractional rect into real pixel coordinates for a video
  /// of the given [videoWidth] x [videoHeight]. FFmpeg's `delogo` filter
  /// wants even integers for x/y/w/h, so we round accordingly.
  ({int x, int y, int w, int h}) toPixelRect({
    required int videoWidth,
    required int videoHeight,
  }) {
    int x = (xFraction * videoWidth).round();
    int y = (yFraction * videoHeight).round();
    int w = (widthFraction * videoWidth).round();
    int h = (heightFraction * videoHeight).round();

    // delogo requires even dimensions/offsets on some builds — snap down.
    x -= x % 2;
    y -= y % 2;
    w -= w % 2;
    h -= h % 2;

    // Keep the box inside the frame.
    if (x + w > videoWidth) w = videoWidth - x;
    if (y + h > videoHeight) h = videoHeight - y;

    return (x: x, y: y, w: w, h: h);
  }
}
