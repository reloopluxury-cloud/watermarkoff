import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../models/mask_rect.dart';
import '../theme/app_theme.dart';
import 'processing_screen.dart';

class MaskSelectionScreen extends StatefulWidget {
  final File videoFile;
  const MaskSelectionScreen({super.key, required this.videoFile});

  @override
  State<MaskSelectionScreen> createState() => _MaskSelectionScreenState();
}

class _MaskSelectionScreenState extends State<MaskSelectionScreen> {
  late final VideoPlayerController _controller;
  bool _ready = false;

  // Box position/size as fractions (0-1) of the preview area.
  double _x = 0.35, _y = 0.05, _w = 0.3, _h = 0.12;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.file(widget.videoFile)
      ..initialize().then((_) {
        setState(() => _ready = true);
        _controller.setLooping(true);
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _resetBox() {
    setState(() {
      _x = 0.35;
      _y = 0.05;
      _w = 0.3;
      _h = 0.12;
    });
  }

  void _continue() {
    final mask = MaskRect(
      xFraction: _x,
      yFraction: _y,
      widthFraction: _w,
      heightFraction: _h,
    );
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ProcessingScreen(
          videoFile: widget.videoFile,
          mask: mask,
          videoWidth: _controller.value.size.width.toInt(),
          videoHeight: _controller.value.size.height.toInt(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select Watermark')),
      body: Column(
        children: [
          Expanded(
            child: _ready
                ? Center(
                    child: AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          final areaW = constraints.maxWidth;
                          final areaH = constraints.maxHeight;
                          return Stack(
                            children: [
                              VideoPlayer(_controller),
                              Positioned(
                                left: _x * areaW,
                                top: _y * areaH,
                                width: _w * areaW,
                                height: _h * areaH,
                                child: _DraggableMaskBox(
                                  onDrag: (dx, dy) {
                                    setState(() {
                                      _x = (_x + dx / areaW).clamp(0.0, 1.0 - _w);
                                      _y = (_y + dy / areaH).clamp(0.0, 1.0 - _h);
                                    });
                                  },
                                  onResize: (dw, dh) {
                                    setState(() {
                                      _w = (_w + dw / areaW).clamp(0.05, 1.0 - _x);
                                      _h = (_h + dh / areaH).clamp(0.05, 1.0 - _y);
                                    });
                                  },
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  )
                : const Center(child: CircularProgressIndicator()),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Drag the box over the watermark or logo',
              style: TextStyle(color: AppColors.outline, fontSize: 13),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                IconButton(
                  onPressed: _resetBox,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Reset box',
                ),
                const Spacer(),
                Expanded(
                  flex: 3,
                  child: ElevatedButton(
                    onPressed: _ready ? _continue : null,
                    child: const Text('Continue'),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// A simple draggable + bottom-right-resizable rectangle overlay.
class _DraggableMaskBox extends StatelessWidget {
  final void Function(double dx, double dy) onDrag;
  final void Function(double dw, double dh) onResize;

  const _DraggableMaskBox({required this.onDrag, required this.onResize});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        GestureDetector(
          onPanUpdate: (details) => onDrag(details.delta.dx, details.delta.dy),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primary, width: 2),
              color: AppColors.primary.withOpacity(0.15),
            ),
          ),
        ),
        Positioned(
          right: 0,
          bottom: 0,
          child: GestureDetector(
            onPanUpdate: (details) =>
                onResize(details.delta.dx, details.delta.dy),
            child: Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Icon(Icons.open_in_full, size: 12, color: Colors.black),
            ),
          ),
        ),
      ],
    );
  }
}
