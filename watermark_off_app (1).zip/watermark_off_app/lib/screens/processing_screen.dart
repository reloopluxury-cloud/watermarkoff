import 'dart:io';
import 'package:flutter/material.dart';
import '../models/mask_rect.dart';
import '../services/video_service.dart';
import '../theme/app_theme.dart';
import 'preview_result_screen.dart';

class ProcessingScreen extends StatefulWidget {
  final File videoFile;
  final MaskRect mask;
  final int videoWidth;
  final int videoHeight;

  const ProcessingScreen({
    super.key,
    required this.videoFile,
    required this.mask,
    required this.videoWidth,
    required this.videoHeight,
  });

  @override
  State<ProcessingScreen> createState() => _ProcessingScreenState();
}

class _ProcessingScreenState extends State<ProcessingScreen> {
  double _progress = 0.0;
  String _status = 'Extracting frames...';
  String? _error;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<void> _run() async {
    try {
      final output = await VideoService.removeWatermark(
        inputVideo: widget.videoFile,
        mask: widget.mask,
        videoWidth: widget.videoWidth,
        videoHeight: widget.videoHeight,
        onProgress: (p, label) {
          if (!mounted) return;
          setState(() {
            _progress = p;
            _status = label;
          });
        },
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => PreviewResultScreen(
            originalFile: widget.videoFile,
            resultFile: output,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Processing')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: _error != null
              ? Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline,
                        color: AppColors.error, size: 40),
                    const SizedBox(height: 12),
                    Text('Something went wrong:\n$_error',
                        textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Go Back'),
                    ),
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 96,
                      height: 96,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CircularProgressIndicator(
                            value: _progress,
                            strokeWidth: 6,
                            backgroundColor: AppColors.surfaceContainerHigh,
                            valueColor: const AlwaysStoppedAnimation(
                                AppColors.primary),
                          ),
                          Text('${(_progress * 100).toInt()}%'),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(_status,
                        style: const TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 8),
                    Text(
                      'Running fully on-device — nothing is uploaded.',
                      style: TextStyle(color: AppColors.outline, fontSize: 12),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
