import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class FileSizeWarningScreen extends StatelessWidget {
  final String actualMb;
  const FileSizeWarningScreen({super.key, required this.actualMb});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('File too large')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.warning_amber_rounded,
                color: AppColors.error, size: 48),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.errorContainer.withOpacity(0.15),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.error.withOpacity(0.4)),
              ),
              child: Column(
                children: [
                  Text(
                    'Video too large (${actualMb}MB)',
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'Trim to under 10MB to continue.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.outline),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                // Hook up a trim screen here later (e.g. using a video
                // trimmer package) — out of scope for v1.
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Choose Another Video'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
