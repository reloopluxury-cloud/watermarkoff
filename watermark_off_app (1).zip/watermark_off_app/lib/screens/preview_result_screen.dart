import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:gal/gal.dart';
import '../theme/app_theme.dart';

class PreviewResultScreen extends StatefulWidget {
  final File originalFile;
  final File resultFile;

  const PreviewResultScreen({
    super.key,
    required this.originalFile,
    required this.resultFile,
  });

  @override
  State<PreviewResultScreen> createState() => _PreviewResultScreenState();
}

class _PreviewResultScreenState extends State<PreviewResultScreen> {
  late VideoPlayerController _controller;
  bool _showingResult = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load(widget.resultFile);
  }

  void _load(File file) {
    _controller = VideoPlayerController.file(file)
      ..initialize().then((_) {
        setState(() {});
        _controller.play();
        _controller.setLooping(true);
      });
  }

  void _toggle() {
    final wasPlaying = _controller.value.isPlaying;
    _controller.pause();
    _controller.dispose();
    setState(() {
      _showingResult = !_showingResult;
      _load(_showingResult ? widget.resultFile : widget.originalFile);
    });
    if (wasPlaying) _controller.play();
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await Gal.putVideo(widget.resultFile.path);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Saved to gallery')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save: $e')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Result')),
      body: Column(
        children: [
          Expanded(
            child: Center(
              child: _controller.value.isInitialized
                  ? AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: VideoPlayer(_controller),
                    )
                  : const CircularProgressIndicator(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ChoiceChip(
                  label: const Text('Before'),
                  selected: !_showingResult,
                  onSelected: (_) {
                    if (_showingResult) _toggle();
                  },
                ),
                const SizedBox(width: 12),
                ChoiceChip(
                  label: const Text('After'),
                  selected: _showingResult,
                  onSelected: (_) {
                    if (!_showingResult) _toggle();
                  },
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: _saving
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.download),
                    label: const Text('Save to Gallery'),
                  ),
                ),
                const SizedBox(width: 12),
                OutlinedButton.icon(
                  onPressed: () {
                    // Wire up share_plus here if you want native share sheet.
                  },
                  icon: const Icon(Icons.share_outlined),
                  label: const Text('Share'),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () => Navigator.of(context)
                .popUntil((route) => route.isFirst),
            child: Text('Edit Mask Again',
                style: TextStyle(color: AppColors.outline)),
          ),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
