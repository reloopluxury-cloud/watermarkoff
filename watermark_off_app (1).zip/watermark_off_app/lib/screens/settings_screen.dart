import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _autoDetect = false; // v2 feature — see README for how to add it.
  bool _keepOriginalQuality = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text('Auto-detect watermark position'),
            subtitle: const Text('Not yet implemented — see README'),
            value: _autoDetect,
            onChanged: (v) => setState(() => _autoDetect = v),
          ),
          SwitchListTile(
            title: const Text('Keep original video quality'),
            subtitle: const Text('Uses CRF 18 (near-lossless) re-encoding'),
            value: _keepOriginalQuality,
            onChanged: (v) => setState(() => _keepOriginalQuality = v),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.shield_outlined, color: AppColors.primary),
            title: const Text('About'),
            subtitle: const Text(
              'WatermarkOff processes video entirely on this device. '
              'No video, frame, or file is ever uploaded or sent to a server.',
            ),
          ),
        ],
      ),
    );
  }
}
