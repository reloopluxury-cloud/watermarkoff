import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Matches the 3-tab bottom bar from the Stitch design: Editor / Vault / Privacy.
/// Only "Editor" is wired to real functionality in this v1 — Vault and
/// Privacy are placeholders you can build out next (e.g. Vault = list of
/// past processed videos kept in local app storage).
class WatermarkOffBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const WatermarkOffBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: onTap,
      backgroundColor: AppColors.surfaceContainerLow,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.movie_creation_outlined),
          activeIcon: Icon(Icons.movie_creation),
          label: 'Editor',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.lock_outline),
          label: 'Vault',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.shield_outlined),
          label: 'Privacy',
        ),
      ],
    );
  }
}
