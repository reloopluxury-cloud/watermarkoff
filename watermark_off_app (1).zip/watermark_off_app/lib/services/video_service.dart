import 'dart:io';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path_provider/path_provider.dart';
import '../models/mask_rect.dart';

/// Max upload size, in bytes. Matches the product requirement (10MB).
const int kMaxVideoBytes = 10 * 1024 * 1024;

class VideoTooLargeException implements Exception {
  final int actualBytes;
  VideoTooLargeException(this.actualBytes);

  String get actualMb => (actualBytes / (1024 * 1024)).toStringAsFixed(1);
}

/// Progress callback: 0.0 -> 1.0
typedef ProgressCallback = void Function(double progress, String statusLabel);

class VideoService {
  /// Throws [VideoTooLargeException] if the file exceeds the 10MB cap.
  static Future<void> assertUnderSizeLimit(File file) async {
    final bytes = await file.length();
    if (bytes > kMaxVideoBytes) {
      throw VideoTooLargeException(bytes);
    }
  }

  /// Runs the actual offline watermark removal.
  ///
  /// [videoWidth]/[videoHeight] should come from the VideoPlayerController
  /// after it's initialized (see mask_selection_screen.dart), so the
  /// fractional [mask] can be converted into real pixel coordinates.
  ///
  /// V1 STRATEGY — FFmpeg `delogo` filter:
  /// This reconstructs the masked region using neighboring pixels across
  /// frames (temporal + spatial interpolation). It runs entirely on-device,
  /// no model download required, and works well for logos/timestamps sitting
  /// on a relatively static or simple background.
  ///
  /// UPGRADE PATH: To move to AI-based inpainting later (better results on
  /// busy/moving backgrounds), replace the body of this method with a call
  /// into a TFLite/Core ML inpainting model per-frame instead of the
  /// `-vf delogo=...` filter below, then re-mux frames back with FFmpeg
  /// exactly the same way. Everything else in the app (mask UI, progress
  /// screen, save/share) stays the same.
  static Future<File> removeWatermark({
    required File inputVideo,
    required MaskRect mask,
    required int videoWidth,
    required int videoHeight,
    required ProgressCallback onProgress,
  }) async {
    onProgress(0.05, 'Reading video...');

    final pixelRect = mask.toPixelRect(
      videoWidth: videoWidth,
      videoHeight: videoHeight,
    );

    final tempDir = await getTemporaryDirectory();
    final outputPath =
        '${tempDir.path}/watermarkoff_${DateTime.now().millisecondsSinceEpoch}.mp4';

    // -crf 18 keeps the re-encoded video visually near-lossless.
    // -c:a copy leaves the audio stream byte-for-byte untouched.
    // show=0 means "just fix it", not "draw a debug box around it".
    final filter =
        'delogo=x=${pixelRect.x}:y=${pixelRect.y}:w=${pixelRect.w}:h=${pixelRect.h}:show=0';

    final command = [
      '-y',
      '-i', _quote(inputVideo.path),
      '-vf', '"$filter"',
      '-c:v', 'libx264',
      '-preset', 'medium',
      '-crf', '18',
      '-c:a', 'copy',
      _quote(outputPath),
    ].join(' ');

    onProgress(0.15, 'Removing watermark...');

    final session = await FFmpegKit.execute(command);
    final returnCode = await session.getReturnCode();

    if (!ReturnCode.isSuccess(returnCode)) {
      final logs = await session.getAllLogsAsString();
      throw Exception('FFmpeg processing failed:\n$logs');
    }

    onProgress(1.0, 'Done');
    return File(outputPath);
  }

  static String _quote(String path) => '"$path"';
}
