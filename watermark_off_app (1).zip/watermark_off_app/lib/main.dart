import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const WatermarkOffApp());
}

class WatermarkOffApp extends StatelessWidget {
  const WatermarkOffApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'WatermarkOff',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const HomeScreen(),
    );
  }
}
